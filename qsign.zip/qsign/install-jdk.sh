#!/bin/bash

# 定义彩虹色的颜色代码
RED='\033[0;31m'
ORANGE='\033[0;33m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
INDIGO='\033[0;36m'
VIOLET='\033[0;35m'
NC='\033[0m' # 恢复默认颜色

# 检查当前系统类型
if [[ -f /etc/os-release ]]; then
    source /etc/os-release
    OS=$ID
elif [[ -f /etc/redhat-release ]]; then
    OS="centos"
else
    echo -e "${RED}无法确定当前系统类型${NC}"
    exit 1
fi

echo -e "${INDIGO}检测到的系统类型为: $OS${NC}"

# 检查是否已安装 JDK
if command -v java &>/dev/null; then
    echo -e "${GREEN}你已经安装了 JDK，不需要再安装了${NC}"
    exit 0
fi

# 更新软件包源
echo -e "${INDIGO}正在更新软件包源...${NC}"
if [[ $OS == "centos" ]]; then
    sudo yum update
elif [[ $OS == "ubuntu" ]]; then
    sudo apt-get update
elif [[ $OS == "debian" ]]; then
    sudo apt-get update
fi

# 显示 JDK 版本选择菜单
echo -e "${YELLOW}请选择要安装的 JDK 版本:${NC}"
echo -e "1. JDK 1.8"
echo -e "2. JDK 11"
echo -e "${ORANGE}推荐 JDK 1.8${NC}"
read -p "请输入选项 (1-2): " choice

# 根据用户选择执行相应的安装命令
if [[ $choice == "1" ]]; then
    # 安装 JDK 1.8
    echo -e "${BLUE}正在安装 JDK 1.8...${NC}"
    if [[ $OS == "centos" ]]; then
        sudo yum install -y java-1.8.0-openjdk
    elif [[ $OS == "ubuntu" ]]; then
        sudo apt-get install -y openjdk-8-jdk
    elif [[ $OS == "debian" ]]; then
        sudo apt-get install -y openjdk-8-jdk
    fi

    # 检查验证结果
    if [[ $? -ne 0 ]]; then
        echo -e "${RED}JDK 1.8 安装失败${NC}"
        read -p "是否尝试安装 JDK 11？(yes/no): " retry_choice
        if [[ $retry_choice == "yes" ]]; then
            # 安装 JDK 11
            echo -e "${BLUE}正在安装 JDK 11...${NC}"
            if [[ $OS == "centos" ]]; then
                sudo yum install -y java-11-openjdk
            elif [[ $OS == "ubuntu" ]]; then
                sudo apt-get install -y openjdk-11-jdk
            elif [[ $OS == "debian" ]]; then
                sudo apt-get install -y openjdk-11-jdk
            fi

            # 检查验证结果
            if [[ $? -ne 0 ]]; then
                echo -e "${RED}JDK 11 安装失败，请手动安装 JDK${NC}"
                exit 1
            else
                echo -e "${GREEN}JDK 11 安装成功！${NC}"
                exit 0
            fi
        else
            echo -e "${RED}安装失败，请手动安装 JDK${NC}"
            exit 1
        fi
    fi

elif [[ $choice == "2" ]]; then
    # 安装 JDK 11
    echo -e "${BLUE}正在安装 JDK 11...${NC}"
    if [[ $OS == "centos" ]]; then
        sudo yum install -y java-11-openjdk
    elif [[ $OS == "ubuntu" ]]; then
        sudo apt-get install -y openjdk-11-jdk
    elif [[ $OS == "debian" ]]; then
        sudo apt-get install -y openjdk-11-jdk
    fi

    # 检查验证结果
    if [[ $? -ne 0 ]]; then
        echo -e "${RED}JDK 11 安装失败${NC}"
        read -p "是否尝试安装 JDK 1.8？(yes/no): " retry_choice
        if [[ $retry_choice == "yes" ]]; then
            # 安装 JDK 1.8
            echo -e "${BLUE}正在安装 JDK 1.8...${NC}"
            if [[ $OS == "centos" ]]; then
                sudo yum install -y java-1.8.0-openjdk
            elif [[ $OS == "ubuntu" ]]; then
                sudo apt-get install -y openjdk-8-jdk
            elif [[ $OS == "debian" ]]; then
                sudo apt-get install -y openjdk-8-jdk
            fi

            # 检查验证结果
            if [[ $? -ne 0 ]]; then
                echo -e "${RED}JDK 1.8 安装失败，请手动安装 JDK${NC}"
                exit 1
            else
                echo -e "${GREEN}JDK 1.8 安装成功！${NC}"
                exit 0
            fi
        else
            echo -e "${RED}安装失败，请手动安装 JDK${NC}"
            exit 1
        fi
    fi

else
    echo -e "${RED}无效的选择${NC}"
    exit 1
fi

# 验证 JDK 安装
java -version

# 检查验证结果
if [[ $? -ne 0 ]]; then
    echo -e "${RED}安装失败，请检查安装命令和系统兼容性${NC}"
    exit 1
else
    echo -e "${GREEN}JDK 安装成功！${NC}"
fi
